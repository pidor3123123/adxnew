# Руководство по проверке API wallet.php

## Способы проверки

### 1. Через консоль браузера (рекомендуется)

1. Откройте сайт `https://adx.finance`
2. Войдите в систему (если не авторизованы)
3. Откройте консоль разработчика (F12)
4. Перейдите на вкладку **Console**
5. Выполните команды:

```javascript
// Проверка балансов
fetch('/api/wallet.php?action=balances&_t=' + Date.now(), {
    headers: {
        'Authorization': 'Bearer ' + (localStorage.getItem('auth_token') || '')
    }
})
.then(r => r.json())
.then(data => console.log('Balances:', data))
.catch(err => console.error('Error:', err));

// Проверка транзакций
fetch('/api/wallet.php?action=transactions&limit=10&_t=' + Date.now(), {
    headers: {
        'Authorization': 'Bearer ' + (localStorage.getItem('auth_token') || '')
    }
})
.then(r => r.json())
.then(data => console.log('Transactions:', data))
.catch(err => console.error('Error:', err));
```

**Ожидаемый результат:**
- Успех: `{success: true, balances: [...], total_usd: ...}`
- Ошибка авторизации: `{success: false, error: "Unauthorized"}`
- Ошибка сервера: `{success: false, error: "...", version: "2.0.1"}`

### 2. Через Network tab

1. Откройте сайт и консоль (F12)
2. Перейдите на вкладку **Network**
3. Откройте страницу `wallet.html`
4. Найдите запросы к `wallet.php` в списке
5. Кликните на запрос
6. Перейдите на вкладку **Response**

**Проверьте:**
- **Status:** должен быть `200 OK` (не 500)
- **Content-Type:** должен быть `application/json` (не `text/html`)
- **Response:** должен быть валидный JSON

### 3. Через диагностический скрипт

1. Откройте `https://adx.finance/test_wallet_simple.php?test=step2`
2. Проверьте, что все файлы найдены
3. Проверьте `https://adx.finance/test_wallet_simple.php?test=step6`
4. Если все шаги успешны, значит проблема в логике wallet.php

### 4. Прямой запрос через браузер

1. Откройте новую вкладку
2. Войдите на сайт в другой вкладке (чтобы получить токен)
3. Скопируйте токен из localStorage:
   ```javascript
   localStorage.getItem('auth_token')
   ```
4. Откройте URL:
   ```
   https://adx.finance/api/wallet.php?action=balances
   ```
   (добавьте заголовок Authorization через расширение браузера или используйте curl)

### 5. Через curl (если есть доступ к терминалу)

```bash
# Получить токен (нужно сначала войти на сайте)
TOKEN="ваш_токен_из_localStorage"

# Проверка балансов
curl -H "Authorization: Bearer $TOKEN" \
     "https://adx.finance/api/wallet.php?action=balances"

# Проверка транзакций
curl -H "Authorization: Bearer $TOKEN" \
     "https://adx.finance/api/wallet.php?action=transactions&limit=10"
```

## Что проверять

### ✅ Успешный ответ

```json
{
  "success": true,
  "balances": [
    {
      "currency": "USD",
      "balance": 1000.00,
      "usd_value": 1000.00
    }
  ],
  "total_usd": 1000.00
}
```

### ❌ Ошибка авторизации

```json
{
  "success": false,
  "error": "Unauthorized"
}
```

**Решение:** Войдите на сайте или проверьте токен

### ❌ Ошибка 500 (Internal Server Error)

```json
{
  "success": false,
  "error": "...",
  "version": "2.0.1",
  "details": {...}
}
```

**Решение:** 
- Проверьте логи сервера
- Проверьте, что все файлы загружены
- Используйте `test_wallet_simple.php` для диагностики

### ❌ HTML вместо JSON

Если видите HTML страницу вместо JSON:
- Файл не найден (404)
- Фатальная ошибка PHP до установки заголовков
- Проверьте логи сервера

## Быстрая проверка через консоль

Скопируйте и выполните в консоли браузера на сайте:

```javascript
// Полная проверка API wallet
async function testWalletAPI() {
    const token = localStorage.getItem('auth_token');
    if (!token) {
        console.error('❌ Не авторизован. Войдите на сайте.');
        return;
    }
    
    console.log('🔍 Проверка API wallet.php...');
    
    // Тест 1: Балансы
    try {
        const balancesRes = await fetch('/api/wallet.php?action=balances&_t=' + Date.now(), {
            headers: {
                'Authorization': 'Bearer ' + token
            }
        });
        
        const balancesData = await balancesRes.json();
        console.log('✅ Балансы:', balancesData);
        
        if (!balancesData.success) {
            console.error('❌ Ошибка получения балансов:', balancesData.error);
        }
    } catch (err) {
        console.error('❌ Ошибка запроса балансов:', err);
    }
    
    // Тест 2: Транзакции
    try {
        const transRes = await fetch('/api/wallet.php?action=transactions&limit=10&_t=' + Date.now(), {
            headers: {
                'Authorization': 'Bearer ' + token
            }
        });
        
        const transData = await transRes.json();
        console.log('✅ Транзакции:', transData);
        
        if (!transData.success) {
            console.error('❌ Ошибка получения транзакций:', transData.error);
        }
    } catch (err) {
        console.error('❌ Ошибка запроса транзакций:', err);
    }
}

// Запустить проверку
testWalletAPI();
```

## Проверка через страницу wallet.html

1. Откройте `https://adx.finance/wallet.html`
2. Откройте консоль (F12)
3. Проверьте запросы в Network tab
4. Если видите ошибки 500 — проблема в API
5. Если видите ошибки авторизации — проблема с токеном

## Устранение проблем

### Проблема: 500 Internal Server Error

**Диагностика:**
1. Откройте `https://adx.finance/test_wallet_simple.php?test=step2`
2. Проверьте, какие файлы найдены
3. Если файлы не найдены — загрузите папку `config/` на сервер
4. Если файлы найдены, но step6 не работает — проблема в коде

**Решение:**
- Убедитесь, что папка `config/` загружена в `public_html/config/`
- Проверьте права доступа к файлам (должны быть 644)
- Проверьте логи сервера для детальной информации

### Проблема: HTML вместо JSON

**Причина:** Фатальная ошибка PHP до установки заголовков

**Решение:**
- Проверьте логи сервера
- Используйте `test_wallet_simple.php` для пошаговой диагностики
- Убедитесь, что используется последняя версия wallet.php (2.0.1)

### Проблема: Unauthorized

**Причина:** Не авторизован или токен недействителен

**Решение:**
- Войдите на сайте
- Проверьте, что токен есть в localStorage: `localStorage.getItem('auth_token')`
- Обновите страницу и попробуйте снова

## Готово!

После проверки вы будете знать:
- ✅ Работает ли API
- ✅ Какие ошибки возникают
- ✅ Где находится проблема
