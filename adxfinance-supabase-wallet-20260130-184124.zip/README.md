# ADX Finance - Торговая платформа

Торговая платформа с админ панелью, построенная на Next.js (админ панель) и PHP (основной API).

## 🚀 Быстрый старт

### Деплой проекта

1. **PHP API на Hostinger**: См. [HOSTINGER_DEPLOY.md](HOSTINGER_DEPLOY.md)
2. **Админ панель на Vercel**: См. [VERCEL_SETUP_GUIDE.md](VERCEL_SETUP_GUIDE.md)
3. **Добавление на GitHub**: См. [GITHUB_SETUP.md](GITHUB_SETUP.md)

## Структура проекта

- **Next.js** - Админ панель (app/)
- **PHP API** - Основной API для торговли и пользователей (api/)
- **MySQL** - Основная база данных
- **Supabase** - База данных для админ панели (синхронизируется с MySQL)

## Настройка перед запуском

### 1. Переменные окружения

Создайте файл `.env` в корне проекта на основе `.env.example`:

```bash
cp .env.example .env
```

Заполните все необходимые переменные:

#### База данных MySQL
```env
DB_HOST=localhost
DB_NAME=novatrade
DB_USER=your_database_user
DB_PASS=your_database_password
DB_CHARSET=utf8mb4
```

#### Supabase
```env
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_ROLE_KEY=your_supabase_service_role_key
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
```

#### Webhook
```env
WEBHOOK_URL=http://your-domain.com/api/webhook.php
WEBHOOK_SECRET=your_secure_webhook_secret
```

#### NextAuth
```env
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your_nextauth_secret
GITHUB_CLIENT_ID=your_github_client_id
GITHUB_CLIENT_SECRET=your_github_client_secret
```

#### Админы
```env
ADMIN_EMAILS=admin1@example.com,admin2@example.com
```

#### CORS
```env
ALLOWED_ORIGINS=http://localhost:3000,https://your-domain.com
```

### 2. Настройка базы данных MySQL

Выполните SQL скрипт для создания структуры базы данных:

```bash
mysql -u your_user -p your_database < database.sql
```

Или импортируйте через phpMyAdmin/другой инструмент.

### 3. Настройка Supabase

1. Создайте проект в Supabase
2. Создайте необходимые таблицы (см. документацию в `SYNC_SETUP.md`)
3. Получите Service Role Key из настроек проекта
4. Установите переменные окружения

### 4. Установка зависимостей

```bash
# Next.js зависимости
npm install

# PHP зависимости (если используются)
composer install
```

## Запуск проекта

### Разработка

```bash
# Запуск Next.js админ панели
npm run dev

# PHP API должен быть доступен через веб-сервер (Apache/Nginx)
# Настройте виртуальный хост или используйте встроенный PHP сервер:
php -S localhost:8000 -t .
```

### Production

#### Next.js (админ панель)

```bash
# Сборка
npm run build

# Запуск
npm start
```

Или используйте платформу типа Vercel для деплоя.

#### PHP API

1. Настройте веб-сервер (Apache/Nginx) для обслуживания PHP файлов
2. Убедитесь, что переменные окружения установлены на сервере
3. Настройте CORS для разрешенных доменов
4. Убедитесь, что база данных доступна

## Синхронизация данных

Данные синхронизируются между MySQL и Supabase:

- **MySQL → Supabase**: Автоматически при создании/обновлении пользователей и балансов
- **Supabase → MySQL**: Через webhook при изменениях в админ панели

Для первоначальной синхронизации:

```bash
php sync_to_supabase.php --all
```

## Безопасность

⚠️ **ВАЖНО**: Перед деплоем убедитесь, что:

1. Все секреты вынесены в переменные окружения (не в коде!)
2. `.env` файл добавлен в `.gitignore`
3. CORS настроен только для разрешенных доменов
4. Webhook secret установлен и защищен
5. База данных доступна только с сервера
6. Используется HTTPS в production

## API Endpoints

### PHP API (основной сайт)

- `POST /api/auth.php?action=register` - Регистрация
- `POST /api/auth.php?action=login` - Вход
- `GET /api/wallet.php?action=balances` - Получить балансы
- `POST /api/trading.php?action=create` - Создать ордер
- `POST /api/webhook.php` - Webhook для синхронизации из админ панели

### Next.js API (админ панель)

- `GET /api/admin/users` - Список пользователей
- `GET /api/admin/stats` - Статистика
- `PATCH /api/admin/users/[id]/balance` - Обновить баланс
- `POST /api/admin/users/[id]/block` - Заблокировать пользователя

## Документация

- `SYNC_SETUP.md` - Инструкции по настройке синхронизации
- `SYNC_INSTRUCTIONS.md` - Детальные инструкции по синхронизации

## Troubleshooting

### Ошибки подключения к базе данных

Проверьте переменные окружения `DB_*` и доступность MySQL сервера.

### Ошибки синхронизации с Supabase

1. Проверьте `SUPABASE_URL` и `SUPABASE_SERVICE_ROLE_KEY`
2. Убедитесь, что таблицы созданы в Supabase
3. Проверьте логи ошибок PHP

### Проблемы с CORS

Убедитесь, что `ALLOWED_ORIGINS` содержит правильные домены и формат корректный (через запятую, без пробелов).

### Webhook не работает

1. Проверьте `WEBHOOK_URL` и `WEBHOOK_SECRET`
2. Убедитесь, что URL доступен из админ панели
3. Проверьте логи ошибок

## Лицензия

Private project
