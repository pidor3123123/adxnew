# Деплой Next.js админ панели на Vercel

## 📋 Обзор

Админ панель (Next.js) деплоится отдельно от PHP API на Vercel. Это бесплатно и очень просто.

## 🚀 Шаг 1: Подготовка к деплою

### Что нужно:

1. Аккаунт на [Vercel](https://vercel.com) (можно зарегистрироваться через GitHub)
2. GitHub репозиторий с вашим проектом (или создайте новый)
3. Данные для переменных окружения (см. ниже)

## 📤 Шаг 2: Загрузка проекта в GitHub

### Если проекта еще нет в GitHub:

1. Создайте новый репозиторий на GitHub
2. В корне проекта выполните:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/ваш-username/ваш-репозиторий.git
git push -u origin main
```

### Если проект уже в GitHub:

Просто убедитесь, что все изменения закоммичены и запушены.

## 🔧 Шаг 3: Настройка переменных окружения

Перед деплоем подготовьте следующие переменные:

### Обязательные переменные:

```env
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://ваш-проект.supabase.co
SUPABASE_SERVICE_ROLE_KEY=ваш_ключ_supabase

# NextAuth
NEXTAUTH_URL=https://ваш-админ-панель.vercel.app
NEXTAUTH_SECRET=сгенерируйте_секретный_ключ

# GitHub OAuth (для входа в админ панель)
GITHUB_CLIENT_ID=ваш_github_client_id
GITHUB_CLIENT_SECRET=ваш_github_client_secret

# Админы
ADMIN_EMAILS=ваш-email@gmail.com,другой-email@gmail.com

# Webhook (URL вашего PHP API на Hostinger)
WEBHOOK_URL=https://ваш-домен.com/api/webhook.php
WEBHOOK_SECRET=тот_же_секрет_что_и_в_hostinger_env
```

### Как получить GitHub OAuth credentials:

1. Перейдите на [GitHub Settings → Developer settings → OAuth Apps](https://github.com/settings/developers)
2. Нажмите **"New OAuth App"**
3. Заполните форму:
   - **Application name**: ADX Finance Admin
   - **Homepage URL**: `https://ваш-админ-панель.vercel.app`
   - **Authorization callback URL**: `https://ваш-админ-панель.vercel.app/api/auth/callback/github`
4. Нажмите **"Register application"**
5. Скопируйте **Client ID** и создайте **Client Secret**

## 🚀 Шаг 4: Деплой на Vercel

### Вариант A: Через веб-интерфейс (рекомендуется)

1. Перейдите на [vercel.com](https://vercel.com)
2. Нажмите **"Add New..."** → **"Project"**
3. Импортируйте ваш GitHub репозиторий:
   - Если репозиторий не виден, нажмите **"Adjust GitHub App Permissions"**
   - Выберите ваш репозиторий
4. Настройте проект:
   - **Framework Preset**: Next.js (должен определиться автоматически)
   - **Root Directory**: `./` (корень проекта)
   - **Build Command**: `npm run build` (по умолчанию)
   - **Output Directory**: `.next` (по умолчанию)
5. **ВАЖНО**: Перед деплоем добавьте переменные окружения:
   - Нажмите **"Environment Variables"**
   - Добавьте все переменные из шага 3
   - Для каждой переменной выберите окружения: **Production**, **Preview**, **Development**
6. Нажмите **"Deploy"**
7. Дождитесь завершения деплоя (обычно 2-3 минуты)

### Вариант B: Через Vercel CLI

1. Установите Vercel CLI:

```bash
npm i -g vercel
```

2. В корне проекта выполните:

```bash
vercel login
vercel
```

3. Следуйте инструкциям:
   - Выберите проект или создайте новый
   - Подтвердите настройки
4. Добавьте переменные окружения:

```bash
vercel env add NEXT_PUBLIC_SUPABASE_URL
vercel env add SUPABASE_SERVICE_ROLE_KEY
vercel env add NEXTAUTH_URL
vercel env add NEXTAUTH_SECRET
vercel env add GITHUB_CLIENT_ID
vercel env add GITHUB_CLIENT_SECRET
vercel env add ADMIN_EMAILS
vercel env add WEBHOOK_URL
vercel env add WEBHOOK_SECRET
```

5. Задеплойте:

```bash
vercel --prod
```

## ✅ Шаг 5: Проверка деплоя

1. После деплоя Vercel предоставит URL вида: `https://ваш-проект.vercel.app`
2. Откройте этот URL в браузере
3. Должна открыться страница входа в админ панель
4. Попробуйте войти через GitHub (используя email из `ADMIN_EMAILS`)

## 🔧 Шаг 6: Настройка кастомного домена (опционально)

Если хотите использовать свой домен:

1. В Vercel перейдите в настройки проекта → **"Domains"**
2. Добавьте ваш домен (например: `admin.ваш-домен.com`)
3. Следуйте инструкциям по настройке DNS:
   - Добавьте CNAME запись в DNS вашего домена
   - Укажите значение, которое даст Vercel
4. Дождитесь активации (обычно несколько минут)
5. Обновите `NEXTAUTH_URL` в переменных окружения на новый домен
6. Обновите `ALLOWED_ORIGINS` в `.env` на Hostinger, добавив новый домен

## 🔄 Шаг 7: Настройка автоматического деплоя

Vercel автоматически деплоит при каждом push в main ветку:

1. Это уже настроено по умолчанию
2. При каждом коммите в `main` будет автоматический деплой
3. Pull Request'ы будут деплоиться в preview окружение

## 🚨 Решение проблем

### Проблема: "Build failed"

**Решение**:
1. Проверьте логи сборки в Vercel
2. Убедитесь, что все зависимости в `package.json`
3. Проверьте, что нет ошибок TypeScript
4. Убедитесь, что Node.js версия совместима (Vercel использует 18.x по умолчанию)

### Проблема: "Environment variables not found"

**Решение**:
1. Убедитесь, что все переменные добавлены в Vercel
2. Проверьте, что переменные добавлены для нужных окружений (Production/Preview/Development)
3. После добавления переменных передеплойте проект

### Проблема: "Cannot access admin panel"

**Решение**:
1. Проверьте, что ваш email в `ADMIN_EMAILS`
2. Убедитесь, что GitHub OAuth настроен правильно
3. Проверьте `NEXTAUTH_URL` - должен совпадать с URL вашего деплоя
4. Проверьте `NEXTAUTH_SECRET` - должен быть установлен

### Проблема: "Supabase connection error"

**Решение**:
1. Проверьте `NEXT_PUBLIC_SUPABASE_URL` и `SUPABASE_SERVICE_ROLE_KEY`
2. Убедитесь, что ключи правильные (из Supabase dashboard)
3. Проверьте, что Supabase проект активен

### Проблема: "Webhook not working"

**Решение**:
1. Проверьте `WEBHOOK_URL` - должен быть доступен из интернета
2. Убедитесь, что `WEBHOOK_SECRET` совпадает с тем, что в `.env` на Hostinger
3. Проверьте, что Hostinger сайт работает и доступен

## 📝 Чек-лист после деплоя

- [ ] Проект задеплоен на Vercel
- [ ] Все переменные окружения добавлены
- [ ] Админ панель открывается по URL
- [ ] Вход через GitHub работает
- [ ] Доступ к админ панели есть (email в ADMIN_EMAILS)
- [ ] Подключение к Supabase работает
- [ ] Webhook настроен и работает
- [ ] Кастомный домен настроен (если используется)

## 🔗 Связь между Hostinger и Vercel

После деплоя обеих частей:

1. **PHP API на Hostinger** обрабатывает:
   - Регистрацию и вход пользователей
   - Торговые операции
   - Балансы и транзакции
   - Синхронизацию с Supabase

2. **Next.js админ панель на Vercel**:
   - Показывает данные из Supabase
   - Позволяет управлять пользователями
   - Отправляет webhook на Hostinger при изменениях

3. **Синхронизация**:
   - MySQL (Hostinger) → Supabase (автоматически через API)
   - Supabase → MySQL (через webhook)

## 🎉 Готово!

Теперь у вас:
- ✅ PHP API работает на Hostinger
- ✅ Админ панель работает на Vercel
- ✅ Данные синхронизируются между системами

## 📚 Дополнительные ресурсы

- [Документация Vercel](https://vercel.com/docs)
- [Next.js на Vercel](https://vercel.com/docs/frameworks/nextjs)
- [Переменные окружения в Vercel](https://vercel.com/docs/concepts/projects/environment-variables)
